var _=(a=>(a.FlatRate="flat",a.Calculated="calculated",a))(_||{}),I="geo-zone",T="conditional-prices",t="item_total",r="region_id";export{T as C,I as G,t as I,r as R,_ as S};
