import{j as r}from"./index-D6Qvdr9G.js";var e=({children:s})=>r.jsx("span",{className:"sr-only",children:s});export{e as V};
