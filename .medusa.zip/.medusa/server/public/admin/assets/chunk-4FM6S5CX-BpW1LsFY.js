var e=new Intl.NumberFormat([],{style:"percent",minimumFractionDigits:2,maximumFractionDigits:4}),m=(r,a=!1)=>{let t=r||0;return a||(t=t/100),e.format(t)};export{m as f};
