var e=r=>typeof r=="string"?Number(r.replace(",",".")):r;export{e as c};
